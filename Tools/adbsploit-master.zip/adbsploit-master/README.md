![](https://raw.githubusercontent.com/mesquidar/adbsploit/master/adbsploit.png)

# ADBSploit

A python based tool for exploiting and managing Android devices via ADB

## Currently on development

- Screenrecord
- Stream Screenrecord
- Extract Contacts
- Extract SMS
- Extract Messasing App Chats WhatsApp/Telegram/Line
- Install Backdoor
- And more...

## Installation
```
# First Download or clone repo
git clone https://github.com/mesquidar/adbsploit.git
# Move to the directory
cd adbsploit
# Install it
python setup.py install
# Excute 
adbsploit
# Enjoy!!
```

### Requirements 
- Python 3.X

## Usage
- Execute the commad: devices
- Then select the device  with: select
- You can connect to device using the command: connect
- Type help for more information

# Functionalities

## v0.2.1
Corrections on help and version commands

### Added
- Screenrecord
- Remote Control

## v0.2

### Added:
- Fixed setup and installation
- Extract Contacts
- Extract SMS
- Send SMS
- Recovery Mode
- Fastboot Mode
- Device Info
- Kill Process

## v0.1
- List Devices
- Connect Devices
- TCPIP
- Forward Ports
- Airplane Managment
- Wifi Managment
- Sound Control
- List/Info Apps
- WPA Supplicant Extraction
- Install/Uninstall Apps
- Shutdown/Reboot
- Logs
- Start/Stop/Clear Apps
- Show Inet/MAC
- Battery Status
- Netstat
- Check/Unlock/Lock Screen
- Turn On/Off Screen
- Swipe Screen
- Screencapture
- Send Keyevent
- Open Browser URL
- Process List
- Dump Meminfo/Hierarchy





