# Changelog for [BlackPhish](https://github.com/iinc0gnit0/BlackPhish)

## 3.8

- Fixed Snapchat

## 3.7

- More commented code

## 3.6

- Small fixes

## 3.5

- ngrok download added to installation

- Added Snapchat

## 3.4

- Fixed issue checking for internet

## 3.3

- Replacing Serveo with ngrok

- Code Revisions

## 3.2

- Bug fixes and improvements

## 3.1

- Fixed not allowing to install localtunnel

- New Logo

- Code Revision

- Added Twitter

## 3.0

- Fixed installation

- Added Netflix

## 2.8

- Bug fixes

## 2.7

- Sometimes showing non-ASCII character error

- Improved installation

- Improved update function

## 2.6

- Bug fixes

## 2.5

- Check for python version

## 2.4

- Small adjustments

- Allow custom domain names

## 2.3

- Bug fixes

## 2.2

- Small adjustments

- Fixed sometimes not catching username/password

## 2.1

- Bug fix

- Added update function

## 2.0

- Added redirect prompt

- Fixed exception bug

- New banner

- New login.php

- Added Google

## 1.8

- Added Facebook page

- Small fixes

## 1.7

- Code touch ups

## 1.6

- Added localhost only

- Some touch ups

## 1.5

- Added localhost.run

## 1.4

- Commented all code in blackphish.py

## 1.3

- Added Localtunnel

- Fixed small bugs

