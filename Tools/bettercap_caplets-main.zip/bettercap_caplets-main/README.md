# bettercap_caplets

## 1) wardriving (print logs to file)
   usage: # bettercap --iface wlan0 -caplet bettercap_log_wifiRecon.cap > wifirecon_logs.txt
