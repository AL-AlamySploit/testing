# SpamAIO
### Spam SMS dan WhatsApp untuk wilayah Indonesia.

``` Tools ini dibuat hanya untuk keisengan semata. Tidak dibuat untuk tindakan kejahatan. Apabila tindakan kejahatan dilakukan dengan tools ini, maka itu diluar tanggung jawab saya selaku pembuat tools ini!!! ```

Dibuat dengan Python3

Requirement :
* requests
 
