# ispy 
<p align="center"><img src="https://raw.githubusercontent.com/Cyb0r9/ispy/master/screenshot/Screenshot%20from%202019-09-30%2022-43-00.png"></p>
<h4 align="center">
ispy : Eternalblue(ms17-010)/Bluekeep(CVE-2019-0708) Scanner and exploiter ( Metasploit automation )
</h4>

# How to install :
```
git clone https://github.com/Cyb0r9/ispy.git
cd ispy
chmod +x setup.sh
./setup.sh
```
# Screenshots :
![Image 2](https://raw.githubusercontent.com/Cyb0r9/ispy/master/screenshot/Screenshot%20from%202019-09-30%2022-45-18.png)
![Image 3](https://raw.githubusercontent.com/Cyb0r9/ispy/master/screenshot/Screenshot%20from%202019-09-30%2022-45-45.png)
![Image 4](https://raw.githubusercontent.com/Cyb0r9/ispy/master/screenshot/Screenshot%20from%202019-09-30%2022-46-04.png)
![Image 5](https://raw.githubusercontent.com/Cyb0r9/ispy/master/screenshot/Screenshot%20from%202019-09-30%2022-47-42.png)

# Tested On :
* Parrot OS 
* Kali linux
# Youtube Channel ( Cyborg )
https://youtube.com/c/Cyborg_TN
# Tutorial ( How to use ispy )
* https://www.youtube.com/watch?v=WCa5N5_zKgw
# info
* GitHub profile : https://github.com/Cyb0r9
* YouTbue channel: https://youtube.com/c/Cyborg_TN
* Ask Fm (ask me): https://ask.fm/Cyborg_TN
* E-mail address : TunisianEagles@protonmail.com
# Disclaimer :
<br><b>usage of ispy for attacking targets without prior mutual consent is illegal.</b></br>
<b>ispy is for security testing purposes only</b>
