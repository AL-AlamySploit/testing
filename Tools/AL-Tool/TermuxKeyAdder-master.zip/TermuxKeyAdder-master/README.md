Script ini untuk menambahkan key seperti ALT, Arrow Key, Home, End, dll

Cara install:
1. pkg install git -y
2. git clone https://github.com/ERRORSYS404/TermuxKeyAdder
3. cd TermuxKeyAdder
4. sh terkeyadd.sh
