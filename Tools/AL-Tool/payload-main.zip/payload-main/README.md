# payload   
[![gambar](https://img.shields.io/youtube/views/o7tUTq9a-Gw?label=Subscribe&style=social)](https://www.youtube.com/c/pythonlife)
![gambar](https://img.shields.io/github/followers/python-life?label=Follow&style=social)

install metasploit | create payload automatically by using metasploit

تحميل الميتاسبلويت اتوماتكيا 
و صنع بايلود اتوماتكيا للختراق الخارجي مع النجروك 
 رابط الشرح في الاسفل حتى تفهم كيفية الاستعمال 
https://youtu.be/6wht7llW31w

``
$ pkg update && upgrade -y
``

``
$ pkg install bash -y;pkg install python -y;pkg install git -y
``

``
$ git clone https://github.com/python-life/payload
``

``
$ cd payload
``

``
$ chmod +x *
``

``
$ bash setup.sh
``


``
$ python payload.py
``

<img src='.Screenshot/img.jpg'>
<img src='.Screenshot/.Screenshot_2.jpg'>

# Enjoy 


## Find Me on :


[![Github](https://img.shields.io/badge/github-python--life-green?style=for-the-badge&logo=github)](https://github.com/python-life)
[![Instagram](https://img.shields.io/badge/instagram-python.life-orange?style=for-the-badge&logo=instagram)](https://www.instagram.com/python.life)
[![Youtube](https://img.shields.io/badge/YouTube-python%20life-red?style=for-the-badge&logo=youtube)](https://www.youtube.com/c/pythonlife)
