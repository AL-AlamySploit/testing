### All in One Hacking tool For Hackers🥇
![](https://img.shields.io/github/license/Z4nzu/hackingtool)
![](https://img.shields.io/github/issues/Z4nzu/hackingtool)
![](https://img.shields.io/github/issues-closed/Z4nzu/hackingtool)
![](https://img.shields.io/badge/Python-3-blue)
![](https://img.shields.io/github/forks/Z4nzu/hackingtool)
![](https://img.shields.io/github/stars/Z4nzu/hackingtool)
![](https://img.shields.io/github/last-commit/Z4nzu/hackingtool)
[![HitCount](http://hits.dwyl.com/Z4nzu/hackingtool.svg)](http://hits.dwyl.com/Z4nzu/hackingtool)
![](https://img.shields.io/badge/platform-Linux%20%7C%20KaliLinux%20%7C%20ParrotOs-blue)

#### Install Kali Linux in WIndows10 Without VirtualBox [YOUTUBE](https://youtu.be/BsFhpIDcd9I)

## Update Available V1.1.0 🚀 
- [x] Added New Tools 
    - [x] Reverse Engineering
    - [x] RAT Tools
    - [x] Web Crawling 
    - [x] Payload Injector
- [x] Multitor Tools update
- [X] Added Tool in wifijamming


# Hackingtool Menu 🧰
{{toc}}

{{tools}}

![](https://github.com/Z4nzu/hackingtool/blob/master/images/A00.png)
![](https://github.com/Z4nzu/hackingtool/blob/master/images/A0.png)
![](https://github.com/Z4nzu/hackingtool/blob/master/images/A1.png)
![](https://github.com/Z4nzu/hackingtool/blob/master/images/A2.png)
![](https://github.com/Z4nzu/hackingtool/blob/master/images/A4.png)

## Installation For Linux <img src="https://konpa.github.io/devicon/devicon.git/icons/linux/linux-original.svg" alt="linux" width="25" height="25"/></p><p align="center">

#### This Tool Must Run As ROOT !!!

    git clone https://github.com/Z4nzu/hackingtool.git
    
    chmod -R 755 hackingtool  
    
    cd hackingtool
    
    sudo pip3 install -r requirement.txt
    
    bash install.sh
    
    sudo hackingtool

 After Following All Steps Just Type In Terminal **root@kaliLinux:~** **hackingtool**

#### Thanks to original Author of the tools used in hackingtool

<img src ="https://img.shields.io/badge/Important-notice-red" />
<h4>Please Don't Use for illegal Activity</h4>

### To do 
- [ ] Release Tool 
- [ ] Add Tools for CTF
- [ ] Want to do automatic 

## Social Media :mailbox_with_no_mail:
[![Twitter](https://img.shields.io/twitter/url?color=%231DA1F2&label=follow&logo=twitter&logoColor=%231DA1F2&style=flat-square&url=https%3A%2F%2Fwww.reddit.com%2Fuser%2FFatChicken277)](https://twitter.com/_Zinzu07)
[![GitHub](https://img.shields.io/badge/-GitHub-181717?style=flat-square&logo=github&link=https://github.com/Z4nzu/)](https://github.com/Z4nzu/)
##### Your Favourite Tool is not in hackingtool or Suggestions Please [CLICK HERE](https://forms.gle/b235JoCKyUq5iM3t8)
![Z4nzu's github stats](https://github-readme-stats.vercel.app/api?username=Z4nzu&show_icons=true&title_color=fff&icon_color=79ff97&text_color=9f9f9f&bg_color=151515)

<a href="https://www.buymeacoffee.com/Zinzu" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/arial-yellow.png" alt="Buy Me A Coffee" style="height: 50px !important;width: 50px !important;"></a>

#### Don't Forgot to share with Your Friends 
#### Thank you..!!
