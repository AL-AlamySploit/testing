from profil3r.core import Core

CONFIG = './config/config.json'

profil3r = Core(CONFIG).run()